window.addEventListener('DOMContentLoaded', () => 
{
    const boxes = Array.from(document.querySelectorAll('.box'));
    const playerDisplay = document.querySelector('.display-player');
    const resetButton = document.querySelector('#rstButt');
    const announcer = document.querySelector('.announcer');

    let board = ['0', '1', '2', '3', '4', '5', '6', '7', '8','9', '10', '11', '12', '13', '14', '15'];
    let currentP = 'X';
    let playG = true;

    const winningConditions = 
    [
        [0,1,2,3],
        [4,5,6,7],
        [8,9,10,11],
        [12,13,14,15],
        [0,4,8,12],
        [1,5,9,13],
        [2,6,10,14],
        [3,7,11,15],
        [0,5,10,15],
        [3,6,9,12]
    ];

    const X_TEXT = 'PLAYERX_WON';
    const O_TEXT = 'PLAYERO_WON';
    const TIE = 'TIE';



    function handleResultValidation() 
    {
        let rndWon = false;
        for (let i = 0; i <= 7; i++) 
        {
            const winCondition = winningConditions[i];
            const a = board[winCondition[0]];
            const b = board[winCondition[1]];
            const c = board[winCondition[2]];
            const d = board[winCondition[3]];
            if (a === '' || b === '' || c === ''|| d === '') 
            {
                continue;
            }
            if (a === d && b === c && c === d && b === d)  
            {
                rndWon = true;
                break;
            }
        }

    if (rndWon) 
        {
            announce(currentP === 'X' ? X_TEXT : O_TEXT);
            playG = false;
            return;
        }
    

    if (!board.includes(''))
    
        announce(TIE);
    }

    const announce = (type) => 
    {
        switch(type)
        {
            case X_TEXT:
                announcer.innerHTML = 'Congrats!! Player <span class="playerO">O</span> Won';
                break;
            case O_TEXT:
                announcer.innerHTML = 'Congrats!! Player <span class="playerXcurrentP">X</span> Won';
                break;
            case TIE:
                announcer.innerText = 'Tie';
        }
        announcer.classList.remove('hide');
    };

    const isValidAction = (box) => 
    {
        if (box.innerText === 'X' || box.innerText === 'O')
        {
            return false;
        }

        return true;
    };

    const updateBoard =  (index) => 
    {
        board[index] = currentP;
    }

    const changePlayer = () =>
    {
        playerDisplay.classList.remove(`player${currentP}`);
        currentP = currentP === 'X' ? 'O' : 'X';
        playerDisplay.innerText = currentP;
        playerDisplay.classList.add(`player${currentP}`);
    }

    const userAction = (box, index) => 
    {
        if(isValidAction(box) && playG) 
        {
            box.innerText = currentP;
            box.classList.add(`player${currentP}`);
            updateBoard(index);
            handleResultValidation();
            changePlayer();
        }
    }
    
    const resetBoard = () => 
    {
        board = ['', '', '', '', '', '', '', '', '','', '', '', '', '', '', ''];
        playG = true;
        announcer.classList.add('hide');

        if (currentP === 'O') 
        {
            changePlayer();
        }

        boxes.forEach(box => 
        {
            box.innerText = '';
            box.classList.remove('playerX');
            box.classList.remove('playerO');
        });
    }

    boxes.forEach( (box, index) => 
    {
        box.addEventListener('click', () => userAction(box, index));
    });

    resetButton.addEventListener('click', resetBoard);
});